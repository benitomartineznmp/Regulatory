import LOG from './logger'

export const RULES = {
  RFC: value => {
    if (value.length > 9) {
      LOG.error(`Se encontro un error en el RFC ${value}`)
    }
    if (value.length < 11) value = `${value}333`

    return value
  },
  'NMP.REPORTES.201': {
    template: 'CREATED',
    description: 'Se ha realizado correctamente la operación.'
  },
  'NMP.REPORTES.400': {
    template: '<%= message %>',
    description: 'La solicitud no se encuentra bien formada.'
  }
}

export default null
