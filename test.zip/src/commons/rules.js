
export const RULESssss = {
  Rfc: {
    rules: [{ rul: `${1} + ${1}` }, { rul: 'regla 2' }]
  },
  Curp: {
    template: 'CREATED',
    description: 'Se ha realizado correctamente la operación.'
  }
}

export default null
