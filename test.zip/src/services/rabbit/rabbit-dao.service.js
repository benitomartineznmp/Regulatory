const { RabbitDAO } = require('../../dao/rabbit/rabbit.dao')

const { rabbitReporte } = require('../../dto/rabbit.dto')

const inputReport = new RabbitDAO(rabbitReporte)

export const RabbitDAOService = {
  inputReport
}

export default null
