import moment from 'moment'
import LOG from '../commons/logger'
import { CODE_INTERNAL_SERVER_ERROR } from '../commons/constants'
import { get } from '../dao/elastic/ealasticSearch'
import { rabbitMangosta } from './rabbit/rabbit.services'
import { Reportes } from '../models/persona'
import { RULES } from '../commons/prueba'

const reportesPrimero = async data => {
  LOG.info('SERVICE: Starting reportesPrimero method', data)
  try {
    await rabbitMangosta.consumeQueuReporte({ id: '123' })
    /*
    const body = {
      query: {
        match_all: {}
      }
    }
    const elastic = await get('md_sap_clientes', body)

    console.log('####')

    for (var key in elastic.hits.hits[0]._source.DatosCliente) {
      //console.log(key)
      const key1 = key.toUpperCase()
      if (RULES.hasOwnProperty(key1)) {
        const regla = RULES[key1](elastic.hits.hits[0]._source.DatosCliente[key])
      }
    }

    console.log('####')

    // obtenemos el tamaño del arregloa
    const tamano = elastic.hits.total
    console.log(tamano)
    */
    // formatear el documento
    const arregloPersonar = []

    LOG.info('SERVICE: End reportesPrimero method')
    return arregloPersonar
  } catch (error) {
    LOG.error('ERROR: End reportesPrimero method ', error)
    throw new InternalServerException(
      createMessageError(CODE_INTERNAL_SERVER_ERROR, { text: error.message })
    )
  }
}

const contain = async (original, valor) => {
  try {
    console.log('###')
    console.log(original)
    console.log('###')
    const regla = await RULES[original]

    /*
    console.log('Como debe funcionar', regla.rules[0].rul)
    console.log(1 + 1)
    const dos = JSON.stringify(regla.rules[0].rul)
    const newStr = dos.slice(1, -1)

    console.log(newStr)
    console.log('######')
    const tataa = [{ id: '1 + 1' }, { id: '2+2' }]
    tataa.map(x => console.log(x.id))

    if (newStr) {
      console.log(regla.rules[0].rul)
      console.log('hola regla')
    } else {
      console.log('Hola error regla')
    }
    original.includes(valor)
    */
  } catch (error) {
    console.log(error)
  }
}
export const reportesServices = {
  reportesPrimero
}

export default null
