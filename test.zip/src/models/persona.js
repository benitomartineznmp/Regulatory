class People {
  // Modulo exportado
  constructor(
    name,
    apellidoPaterno,
    apellidoMaterno,
    rfc,
    tipoCliente,
    fechaNacimiento,
    curp,
    Sexo,
    ActividadEconomica,
    TipoAcredRel,
    PersJuridica,
    GrupoRiesgoCom,
    Calle,
    NumExterior,
    Colonia,
    Cp,
    Localidad,
    HITSIC,
    Nacionalidad,
    TotalIngresos,
    TamanoAcreditado,
    TipoZona
  ) {
    this.name = name
    this.apellidoPaterno = apellidoPaterno
    this.apellidoMaterno = apellidoMaterno
    this.rfc = rfc
    this.tipoCliente = tipoCliente
    this.fechaNacimiento = fechaNacimiento
    this.curp = curp
    this.Sexo = Sexo
    this.ActividadEconomica = ActividadEconomica
    this.TipoAcredRel = TipoAcredRel
    this.PersJuridica = PersJuridica
    this.GrupoRiesgoCom = GrupoRiesgoCom
    this.Calle = Calle
    this.NumExterior = NumExterior
    this.Colonia = Colonia
    this.Cp = Cp
    this.Localidad = Localidad
    this.HITSIC = HITSIC
    this.Nacionalidad = Nacionalidad
    this.TotalIngresos = TotalIngresos
    this.TamanoAcreditado = TamanoAcreditado
    this.TipoZona = TipoZona
  }

  getTipoZona() {
    return this.TipoZona
  }

  setTipoZona(newTipoZona) {
    this.TipoZona = newTipoZona
  }

  getTamanoAcreditado() {
    return this.TamanoAcreditado
  }

  setTamanoAcreditado(newTamanoAcreditado) {
    this.TamanoAcreditado = newTamanoAcreditado
  }

  getTotalIngresos() {
    return this.TotalIngresos
  }

  setTotalIngresos(newTotalIngresos) {
    this.TotalIngresos = newTotalIngresos
  }

  getNacionalidad() {
    return this.Nacionalidad
  }

  setNacionalidad(newNacionalidad) {
    this.Nacionalidad = newNacionalidad
  }

  getHITSIC() {
    return this.HITSIC
  }

  setHITSIC(newHITSIC) {
    this.HITSIC = newHITSIC
  }

  getLocalidad() {
    return this.Localidad
  }

  setLocalidad(newLocalidad) {
    this.Localidad = newLocalidad
  }

  getCp() {
    return this.Cp
  }

  setCp(newCp) {
    this.Cp = newCp
  }

  getColonia() {
    return this.Colonia
  }

  setColonia(newColonia) {
    this.Colonia = newColonia
  }

  getNumExterior() {
    return this.NumExterior
  }

  setNumExterior(newNumExterior) {
    this.NumExterior = newNumExterior
  }

  getCalle() {
    return this.Calle
  }

  setCalle(newCalle) {
    this.Calle = newCalle
  }

  getGrupoRiesgoCom() {
    return this.GrupoRiesgoCom
  }

  setGrupoRiesgoCom(newGrupoRiesgoCom) {
    this.GrupoRiesgoCom = newGrupoRiesgoCom
  }

  getPersJuridica() {
    return this.PersJuridica
  }

  setPersJuridica(newPersJuridica) {
    this.PersJuridica = newPersJuridica
  }

  getTipoAcredRel() {
    return this.TipoAcredRel
  }

  setTipoAcredRel(newTipoAcredRel) {
    this.TipoAcredRel = newTipoAcredRel
  }

  getActividadEconomica() {
    return this.ActividadEconomica
  }

  setActividadEconomica(newActividadEconomica) {
    this.ActividadEconomica = newActividadEconomica
  }

  getSexo() {
    return this.Sexo
  }

  setSexo(newSexo) {
    this.Sexo = newSexo
  }

  getName() {
    return this.name
  }

  setName(newName) {
    this.name = newName
  }
  getapellidoPaterno() {
    return this.apellidoPaterno
  }

  setapellidoPaterno(newapellidoPaterno) {
    this.apellidoPaterno = newapellidoPaterno
  }
  getapellidoMaterno() {
    return this.apellidoMaterno
  }

  setapellidoMaterno(newapellidoMaterno) {
    this.apellidoMaterno = newapellidoMaterno
  }

  getrfc() {
    return this.rfc
  }

  setrfc(newrfc) {
    this.rfc = newrfc
  }
  gettipoCliente() {
    return this.tipoCliente
  }

  settipoCliente(newtipoCliente) {
    this.tipoCliente = newtipoCliente
  }
  getfechaNacimiento() {
    return this.fechaNacimiento
  }

  setfechaNacimiento(newfechaNacimiento) {
    this.fechaNacimiento = newfechaNacimiento
  }

  getcurp() {
    return this.curp
  }

  setcurp(newcurp) {
    this.curp = newcurp
  }
}

export const Reportes = {
  People
}

export default null
